import API from "./Axios";

export const getAllClasses = async () => {
  const res = await API.get("/class/all");
  return res.data;
};

export const createClass = async (data) => {
  const payload = {
    ...data,
    classTeachers: data.classTeachers.map(String),
    subjectTeachers: data.subjectTeachers.map(s => ({
      subject: s.subject,
      teacher: String(s.teacher),
    })),
  };

  const res = await API.post("/class/create", payload);
  return res.data;
};

export const updateClass = async ({ classId, formData }) => {
  const res = await API.patch(`/class/${classId}`, formData);
  return res.data;
};
