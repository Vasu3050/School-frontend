import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Plus } from "lucide-react";
import { loadClasses } from "../../store/classSlice.js";
import ClassFormModal from "./ClassFormModal.jsx";

export default function ManageClasses() {
  const dispatch = useDispatch();
  const { list: classes, loading } = useSelector(
    (state) => state.class
  );

  const [openModal, setOpenModal] = useState(false);

  useEffect(() => {
    dispatch(loadClasses());
  }, [dispatch]);

  return (
    <div className="p-4 sm:p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-semibold">Manage Classes</h1>
          <p className="text-sm text-gray-500">
            Create and manage academic classes
          </p>
        </div>

        <button
          onClick={() => setOpenModal(true)}
          className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
        >
          <Plus size={18} />
          Create Class
        </button>
      </div>

      {/* Table */}
      <div className="bg-white dark:bg-gray-800 rounded shadow overflow-x-auto">
        <table className="min-w-full text-sm">
          <thead className="bg-gray-100 dark:bg-gray-700">
            <tr>
              <th className="px-4 py-3 text-left">Class</th>
              <th className="px-4 py-3 text-left">Division</th>
              <th className="px-4 py-3 text-left">Academic Year</th>
              <th className="px-4 py-3 text-left">Teachers</th>
              <th className="px-4 py-3 text-left">Status</th>
            </tr>
          </thead>
          <tbody>
            {!loading &&
              classes.map((cls) => (
                <tr key={cls._id} className="border-t">
                  <td className="px-4 py-3">{cls.grade}</td>
                  <td className="px-4 py-3">{cls.section}</td>
                  <td className="px-4 py-3">{cls.academicYear}</td>
                  <td className="px-4 py-3">
                    {cls.classTeachers?.length || 0}
                  </td>
                  <td className="px-4 py-3 capitalize">
                    {cls.status}
                  </td>
                </tr>
              ))}
          </tbody>
        </table>

        {!loading && classes.length === 0 && (
          <p className="text-center py-6 text-gray-500">
            No classes found
          </p>
        )}
      </div>

      {openModal && (
        <ClassFormModal
          onClose={() => setOpenModal(false)}
          onSuccess={() => dispatch(loadClasses())}
        />
      )}
    </div>
  );
}
