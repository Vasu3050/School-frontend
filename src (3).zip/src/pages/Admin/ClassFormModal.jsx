import { useDispatch } from "react-redux";
import { useState } from "react";
import { createNewClass } from "../../store/classSlice";
import NotificationModal from "../../components/NotificationModel.jsx";

const GRADES = ["Playgroup", "Nursery", "LKG", "UKG"];
const SECTIONS = ["A", "B", "C", "D"];
const SUBJECTS = [
  "Mathematics",
  "EVS",
  "English",
  "Hindi",
  "Kannada",
  "Drawing",
  "Activity",
  "Other",
];

const academicYears = (() => {
  const y = new Date().getFullYear();
  return Array.from({ length: 6 }, (_, i) => `${y + i}-${y + i + 1}`);
})();

export default function ClassFormModal({ onClose }) {
  const dispatch = useDispatch();
  const [form, setForm] = useState({
    grade: "",
    section: "",
    academicYear: academicYears[0],
    classTeachers: [],
    subjectTeachers: [],
  });
  const [notif, setNotif] = useState(null);

  const submit = async () => {
    try {
      await dispatch(createNewClass(form)).unwrap();
      setNotif({ type: "success", message: "Class created successfully" });
      onClose();
    } catch (e) {
      setNotif({ type: "error", message: e });
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center">
      <div className="bg-white p-6 rounded w-full max-w-lg space-y-4">
        <h2 className="text-lg font-semibold">Create Class</h2>

        <div className="grid grid-cols-2 gap-3">
          <select onChange={e => setForm({ ...form, grade: e.target.value })}>
            <option value="">Select Class</option>
            {GRADES.map(g => <option key={g}>{g}</option>)}
          </select>

          <select onChange={e => setForm({ ...form, section: e.target.value })}>
            <option value="">Section</option>
            {SECTIONS.map(s => <option key={s}>{s}</option>)}
          </select>

          <select
            className="col-span-2"
            value={form.academicYear}
            onChange={e => setForm({ ...form, academicYear: e.target.value })}
          >
            {academicYears.map(y => <option key={y}>{y}</option>)}
          </select>
        </div>

        <div className="flex justify-end gap-2 pt-4">
          <button onClick={onClose}>Cancel</button>
          <button onClick={submit} className="bg-blue-600 text-white px-4 py-2 rounded">
            Create
          </button>
        </div>
      </div>

      {notif && (
        <NotificationModal
          type={notif.type}
          message={notif.message}
          onClose={() => setNotif(null)}
        />
      )}
    </div>
  );
}
