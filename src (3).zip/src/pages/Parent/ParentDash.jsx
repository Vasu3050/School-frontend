import React from 'react'

function ParentDash() {
  return (
    <div>ParentDash</div>
  )
}

export default ParentDash