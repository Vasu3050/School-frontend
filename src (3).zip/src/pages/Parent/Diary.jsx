import React from 'react'

function Diary() {
  return (
    <div>Diary</div>
  )
}

export default Diary