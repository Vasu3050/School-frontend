import React from 'react'

function TeacherDash() {
  return (
    <div>TeacherDash</div>
  )
}

export default TeacherDash