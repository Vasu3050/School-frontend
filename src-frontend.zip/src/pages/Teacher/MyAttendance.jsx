import React from 'react'

function MyAttendance() {
  return (
    <div>MyAttendance</div>
  )
}

export default MyAttendance