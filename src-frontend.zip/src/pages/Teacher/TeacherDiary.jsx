import React from 'react'

function TeacherDiary() {
  return (
    <div>TeacherDiary</div>
  )
}

export default TeacherDiary