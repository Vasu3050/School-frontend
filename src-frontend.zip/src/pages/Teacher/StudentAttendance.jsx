import React from 'react'

function StudentAttendance() {
  return (
    <div>StudentAttendance</div>
  )
}

export default StudentAttendance