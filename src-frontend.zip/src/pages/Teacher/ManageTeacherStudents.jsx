import React from 'react'

function ManageTeacherStudents() {
  return (
    <div>ManageTeacherStudents</div>
  )
}

export default ManageTeacherStudents