import React from 'react'

function Children() {
  return (
    <div>Children</div>
  )
}

export default Children